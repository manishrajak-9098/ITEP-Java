package com.management.controller;
import java.io.*; import jakarta.servlet.*; import jakarta.servlet.http.*;
import com.management.dao.UserDao; import com.management.dto.User;
public class RegisterServlet extends HttpServlet{
 protected void doPost(HttpServletRequest r,HttpServletResponse s)throws IOException{
  User u=new User();
  u.setName(r.getParameter("name")); u.setEmail(r.getParameter("email"));
  u.setPassword(r.getParameter("password")); u.setAddress(r.getParameter("address"));
  if(new UserDao().register(u)) s.sendRedirect("login.html"); else s.sendRedirect("register.html");
 }
}