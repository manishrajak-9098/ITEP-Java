package com.management.controller;
import java.io.*; import jakarta.servlet.*; import jakarta.servlet.http.*;
import com.management.dao.UserDao;
public class LoginServlet extends HttpServlet{
 protected void doPost(HttpServletRequest r,HttpServletResponse s)throws IOException,ServletException{
  if(new UserDao().login(r.getParameter("email"),r.getParameter("password"))){
   r.getSession().setAttribute("email",r.getParameter("email"));
   s.sendRedirect("profile");
  }else{s.sendRedirect("login.html");}
 }
}