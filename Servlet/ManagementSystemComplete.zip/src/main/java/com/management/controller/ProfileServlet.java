package com.management.controller;
import java.io.*; import jakarta.servlet.*; import jakarta.servlet.http.*;
public class ProfileServlet extends HttpServlet{
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws IOException,ServletException{
  if(r.getSession(false)==null){s.sendRedirect("login.html");return;}
  r.getRequestDispatcher("profile.html").forward(r,s);
 }
}