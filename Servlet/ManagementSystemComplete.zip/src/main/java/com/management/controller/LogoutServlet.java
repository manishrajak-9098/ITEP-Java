package com.management.controller;
import java.io.*; import jakarta.servlet.http.*;
public class LogoutServlet extends HttpServlet{
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws IOException{
  r.getSession().invalidate(); s.sendRedirect("login.html");
 }
}