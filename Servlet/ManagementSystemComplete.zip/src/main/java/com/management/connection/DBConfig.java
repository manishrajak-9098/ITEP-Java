package com.management.connection;
public interface DBConfig {
 String DRIVER="com.mysql.cj.jdbc.Driver";
 String URL="jdbc:mysql://localhost:3306/managementsystem";
 String USERNAME="root";
 String PASSWORD="root";
}