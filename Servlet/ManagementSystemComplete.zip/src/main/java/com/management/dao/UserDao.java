package com.management.dao;
import java.sql.*; import java.util.*;
import com.management.connection.DBConnection;
import com.management.dto.User;
public class UserDao{
 public boolean register(User u){
  try{
   Connection con=DBConnection.getConnection();
   PreparedStatement ps=con.prepareStatement("insert into users(name,email,password,address) values(?,?,?,?)");
   ps.setString(1,u.getName()); ps.setString(2,u.getEmail());
   ps.setString(3,u.getPassword()); ps.setString(4,u.getAddress());
   return ps.executeUpdate()>0;
  }catch(Exception e){return false;}
 }
 public boolean login(String email,String pass){
  try{
   Connection con=DBConnection.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from users where email=? and password=?");
   ps.setString(1,email); ps.setString(2,pass);
   return ps.executeQuery().next();
  }catch(Exception e){return false;}
 }
}