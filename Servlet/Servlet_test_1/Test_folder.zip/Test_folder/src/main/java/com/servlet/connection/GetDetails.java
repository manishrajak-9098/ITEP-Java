package com.servlet.connection;

public interface GetDetails {
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String URL = "jdbc:mysql://localhost:3306/itep16";
    String USERNAME = "root";
    String PASSWORD = "root";
}
