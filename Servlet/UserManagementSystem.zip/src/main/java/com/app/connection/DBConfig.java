package com.app.connection;

public interface DBConfig {
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String URL = "jdbc:mysql://localhost:3306/usermanagement";
    String USERNAME = "root";
    String PASSWORD = "root";
}
